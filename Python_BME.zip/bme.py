#!/usr/bin/env python3

""" ------------------------------------------------------------------------------
BME: A script displaying data from a sensor via a TKinter application.
The script communicates with an ESP32 device that is connected to a BME280 sensor.
Communication runs via the websocket interface. The most important parameters
e.g. IP address, port number, and more) are captured in a simple config file.

Sensor data include: temperature, humidity, air pressure, trend for air pressure

File(s): bme.py (Python script), bme_config.dat (configuration file)
Author: SLW
last update: 20210223
------------------------------------------------------------------------------ """

from tkinter import *
import threading
import websocket
import time

debug = False

# a few definitions for the TKinter loog&feel
my_font_very_small = ("Comic Sans", 10)
my_font_small = ("Comic Sans", 12)
my_font_medium = ("Comic Sans", 14)
my_font_large = ("Comic Sans", 20)
col_background = "gray90"
col_inactive = "gray84"
col_graphics = "gray78"
col_active = "light yellow"
width, height = 287, 355
graphics_width, graphics_height = width-20, 80 

class BME:

    def __init__(self):
        if not self.read_config():
            logging.error("Can't open or read bmp_config.dat")
            return
        # initialize operating values
        self.err_status = False
        self.err_msg = ""
        self.temp, self.hum, self.pres, self.trend = 0.0, 0.0, 0.0, 0.0
        self.hist = []
        self.led0, self.led1 = False, False
        self.pres_refresh_active = False
        # start thread for data collection via websocket
        self.ws = websocket.WebSocket()
        self.ws_connected = False
        self.data_update_pending = False
        self.data_thread = threading.Thread(target = self.get_data)
        self.data_thread_running = True
        self.data_thread.start()
        # initiate widgets
        self.root = Tk()
        self.root.title("BME280")
        self.root.minsize(width=width, height=height)
        self.root.configure(background=col_background)
        self.widget_setup()
        # run system
        self.refresh()
        self.root.mainloop()
        
    def widget_setup(self):
        # create text variables
        self.temp_tv = DoubleVar()
        self.hum_tv = DoubleVar()
        self.pres_tv = DoubleVar()
        self.trend_tv = DoubleVar()
        # add title
        row = 0
        self.title_lb = Label(self.root, text="BME Sensor", font=my_font_large, bg=col_background)
        self.title_lb.grid(row=row, column=0, columnspan=4, sticky=EW, padx=5, pady=5)
        # add temperature entry
        row += 1
        self.temp_lb = Label(self.root, text="Temperature", font=my_font_medium, bg=col_background)
        self.temp_lb.grid(row=row, column=0, columnspan=2, sticky=E, padx=5)
        self.temp_entry = Entry(self.root, textvariable=self.temp_tv, disabledbackground=col_inactive,
                                width=6, justify=RIGHT, font=my_font_medium)
        self.temp_entry.config(state='disabled', disabledforeground='black')
        self.temp_entry.grid(row=row, column=2, sticky=E, padx=10)
        self.temp_unit_lb = Label(self.root, text="C", font=my_font_small, bg=col_background)
        self.temp_unit_lb.grid(row=row, column=3, sticky=W, padx=5)
        # add humidity entry
        row += 1
        self.hum_lb = Label(self.root, text="Humidity", font=my_font_medium, bg=col_background)
        self.hum_lb.grid(row=row, column=0, columnspan=2, sticky=E, padx=5)
        self.hum_entry = Entry(self.root, textvariable=self.hum_tv, disabledbackground=col_inactive,
                               width=6, justify=RIGHT, font=my_font_medium)
        self.hum_entry.config(state='disabled', disabledforeground='black')
        self.hum_entry.grid(row=row, column=2, sticky=E, padx=10)
        self.hum_unit_lb = Label(self.root, text="%", font=my_font_small, bg=col_background)
        self.hum_unit_lb.grid(row=row, column=3, sticky=W, padx=5)
        # add pressure entry
        row += 1
        self.pres_lb = Label(self.root, text="Pressure", font=my_font_medium, bg=col_background)
        self.pres_lb.grid(row=row, column=0, columnspan=2, sticky=E, padx=5)
        self.pres_entry = Entry(self.root, textvariable=self.pres_tv, disabledbackground=col_inactive,
                                width=6, justify=RIGHT, font=my_font_medium)
        self.pres_entry.config(state='disabled', disabledforeground='black')
        self.pres_entry.grid(row=row, column=2, sticky=E, padx=10)
        self.pres_unit_lb = Label(self.root, text="mbar", font=my_font_small, bg=col_background)
        self.pres_unit_lb.grid(row=row, column=3, sticky=W, padx=5)
        # add pressure trend entry
        row += 1
        self.trend_lb = Label(self.root, text="Trend", font=my_font_medium, bg=col_background)
        self.trend_lb.grid(row=row, column=0, columnspan=2, sticky=E, padx=5)
        self.trend_entry = Entry(self.root, textvariable=self.trend_tv, disabledbackground=col_inactive,
                                 width=6, justify=RIGHT, font=my_font_medium)
        self.trend_entry.config(state='disabled', disabledforeground='black')
        self.trend_entry.grid(row=row, column=2, sticky=E, padx=10)
        self.trend_unit_lb = Label(self.root, text="1/h", font=my_font_small, bg=col_background)
        self.trend_unit_lb.grid(row=row, column=3, sticky=W, padx=5)
        # add canvas
        row += 1
        self.cv = Canvas(self.root, width=graphics_width, height=graphics_height,
                         bg=col_graphics)
        self.cv.grid(row=row, column=0, columnspan=4, pady=10, padx=10)
        # add separator
        row += 1
        fr = Frame(self.root, height=3, bg='dim gray')
        fr.grid(row=row, column=0, columnspan=4, sticky=EW, padx=10, pady=0)
        # add LED buttons
        row += 1
        self.led0_bt = Button(self.root, text="LED 1", width=5, justify=CENTER,
                              font=my_font_small, command=self.led0_bt_cmd)
        self.led0_bt.on_color='lightgreen'
        self.led0_bt.grid(row=row, column=0, sticky=W, padx=10, pady=10)
        self.led1_bt = Button(self.root, text="LED 2", width=5, justify=CENTER,
                              font=my_font_small, command=self.led1_bt_cmd)
        self.led1_bt.grid(row=row, column=1, pady=10)
        self.set_bt = Button(self.root, text="SET", width=5, justify=CENTER,
                              font=my_font_small, command=self.set_bt_cmd)
        self.led1_bt.on_color='tomato'
        self.set_bt.grid(row=row, column=2, columnspan=2, stick=E, padx=10, pady=10)
        # add label for error message
        row += 1
        self.error_lb = Label(self.root, fg='red', font=my_font_very_small)
        self.error_lb.row=row
        row += 1
        # add exit button
        self.exit_bt = Button(self.root, text="Exit", width=4, justify=CENTER, command=self.exit_bt_cmd)
        self.exit_bt.grid(row=row, column=0, columnspan=4, sticky=EW, padx=10, pady=5)


    def set_error(self, err_msg):
        """ Sets error flag and error message """
        self.err_msg = err_msg
        self.err_status = True
        

    def read_config(self):
        """ Reads basic operating parameters from config file """
        try:
            with open("bme_config.dat", "r") as f:
                lines = f.readlines()
        except IOError:
            return False
        for l in lines:
            if len(l) > 5:
                e = l.split()
                if e[0] == 'IP':
                    self.ip = e[1].strip()
                elif e[0] == 'refresh_cycle':
                    self.refresh_cycle = int(e[1].strip())
                elif e[0] == 'pres_min_range':
                    self.pres_min_range = int(e[1].strip())
                elif e[0] == 'port':
                    self.port = int(e[1].strip())
                else:
                    print("Unrecognized entry in config file:");
                    print(l);
        return True


    def refresh(self):
        """ Refreshes all tkinter widgets with new data.
            Data retrieval is performed via a separate thread.
            This function restarts itself after refresh cycle time """
        if self.data_update_pending:
            if debug: print("[refresh]")
            self.data_update_pending = False
            if self.err_status:
                self.error_lb.config(text = self.err_msg)
                self.error_lb.grid(row=self.error_lb.row, column=0,
                                   columnspan=4, padx=5, pady=5)
            else:
                self.error_lb.grid_forget()    
                self.temp_tv.set("{:4.1f}".format(self.temp))
                self.hum_tv.set("{:4.1f}".format(self.hum))
                if not self.pres_refresh_active:
                    self.pres_tv.set("{:5.1f}".format(self.pres))
                self.trend_tv.set("{:+5.2f}".format(self.trend))
                self.draw_pres_graphics()
        self.root.after(1000, self.refresh)

   
    def led0_bt_cmd(self):
        """ Sets LED 0 """
        if not self.led0:
            self.led0_bt.config(bg=self.led0_bt.on_color)
            msg = "L01"
        else:
            self.led0_bt.config(bg='SystemButtonFace')
            msg = "L00"
        self.led0 = not self.led0
        self.send_msg(msg)

    def led1_bt_cmd(self):
        """ Sets LED 1 """
        if not self.led1:
            self.led1_bt.config(bg=self.led1_bt.on_color)
            msg = "L11"
        else:
            self.led1_bt.config(bg='SystemButtonFace')
            msg = "L10"
        self.led1 = not self.led1
        self.send_msg(msg)
            
 
    def set_bt_cmd(self):
        """ Enables entry for air pressure reference value or -
            if update is pendign - sends the new value to BME device """
        if self.pres_refresh_active:
            self.send_msg("R{:5.1f}".format(self.pres_tv.get()))
            self.pres_entry.config(state=DISABLED)
            self.pres_entry.bind("<Return>", NONE)
            self.pres_refresh_active = False
        else:
            self.pres_entry.config(state=NORMAL)
            self.pres_entry.config(bg=col_active)
            self.pres_entry.bind("<Return>", self.update_pressure)
            self.pres_refresh_active = True


    def update_pressure(self, event):
        """ Sets the air pressure reference value """
        self.send_msg("R{:5.1f}".format(self.pres_tv.get()))
        self.pres_entry.config(state=DISABLED, fg='black')
        self.pres_entry.bind("<Return>", NONE)
        self.pres_refresh_active = False


    def draw_pres_graphics(self):
        """ Plots a simple graphics showing the trend of the air pressure
            to a canvas """
        if len(self.hist) > 0:
            self.cv.delete("all")       # clear canvas
            hist_min, hist_max = int(min(self.hist)), int(max(self.hist)) + 1
            hist_range = hist_max - hist_min
            if hist_range < self.pres_min_range:
                mean = round((hist_min + hist_max) / 2)
                hist_min = mean - self.pres_min_range // 2
                hist_max = mean + self.pres_min_range // 2
                hist_range = hist_max - hist_min
            pos_y_min, pos_y_max = graphics_height - 7, 10
            pos_y_range = pos_y_max - pos_y_min
            # plot lower and upper horizontal lines with label
            self.cv.create_text(3, pos_y_min, text="{:4d}".format(hist_min),
                                justify = LEFT, anchor=W)
            self.cv.create_line(35, pos_y_min, graphics_width, pos_y_min, fill='white')
            self.cv.create_text(3, pos_y_max, text="{:4d}".format(hist_max),
                                   justify = LEFT, anchor=W)
            self.cv.create_line(35, pos_y_max, graphics_width, pos_y_max, fill='white')
            # plot horizontal grid lines between lower and upper range with label
            for hist in range(hist_min + 1, hist_max):
                pos_y = pos_y_min + (hist - hist_min) * pos_y_range / hist_range
                self.cv.create_text(3, pos_y, text="{:4d}".format(hist), justify = LEFT, anchor=W)
                self.cv.create_line(35, pos_y, graphics_width, pos_y, fill='white', dash=(4,4))
            # plot data points
            step_x = (graphics_width - 33) / len(self.hist)
            r = 2
            for x in range(len(self.hist)):
                pos_x = graphics_width - 4 - x * step_x
                pos_y = pos_y_min + (self.hist[x] - hist_min) * pos_y_range / hist_range
                self.cv.create_oval(pos_x - r, pos_y - r, pos_x + r, pos_y + r, fill='blue')
                # plot data line
                if x > 0:
                    self.cv.create_line(prev_pos_x, prev_pos_y, pos_x, pos_y, fill='blue')
                # plot vertical grid lines
                if x % 6 == 0:
                    self.cv.create_line(pos_x, pos_y_min, pos_x, pos_y_max, fill='white', dash=(4,4))
                prev_pos_x, prev_pos_y = pos_x, pos_y           
            self.cv.create_line(pos_x, pos_y_min, pos_x, pos_y_max, fill='white', dash=(4,4))

          
    def exit_bt_cmd(self):
        """ Cancels data collection thread and close window. """
        self.data_thread_running = False
        self.root.destroy()


    def get_data(self):
        """ Retrieves the full set of data from the BME sensor device. """
        while self.data_thread_running:
            if (debug): print("[get_data]")
            while self.ws_connected:        # if ws is in use, just wait a moment
                time.sleep(0.5)
            try:
                self.ws.connect("ws://" + self.ip + ":" + str(self.port), timeout=2)
                self.ws_connected = True
                self.ws.send("T")
                self.temp = float(self.ws.recv())
                self.ws.send("H")
                self.hum = float(self.ws.recv())
                self.ws.send("P")
                self.pres = float(self.ws.recv())
                self.ws.send("C")
                self.trend = float(self.ws.recv())
                self.ws.send("D")
                self.hist = [float(s) for s in self.ws.recv().split(',')]
            except (OSError, ValueError, TypeError) as err:
                self.set_error(err)
                self.err_status = True
            else:
                self.err_status = False
            finally:
                self.ws.close()
                self.ws_connected = False
            self.data_update_pending = True
            time.sleep(self.refresh_cycle)


    def send_msg(self, msg):
        """ Sends a message to the BME sensor device. """
        while self.ws_connected:
            time.sleep(0.5)
        try:
            self.ws.connect("ws://" + self.ip + ":" + str(self.port), timeout=2)
            self.ws_connected = True
            self.ws.send(msg)
            result = self.ws.recv()
            if debug: print("[send_msg]", result)
        except (OSError, ValueError, TypeError) as err:
            self.set_error(err)
            self.err_status = True
        else:
            self.error_status = False
        finally:
            self.ws.close()
            self.ws_connected = False

            
#----------------------------------------------------------------------------
bme = BME()


